
#! /bin/bash

g++ -O3 -o main main.cpp
