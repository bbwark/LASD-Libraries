
#include <iostream>

// #include "testx.hpp"

void test() {
  std::cout << "Hello world!";
}
