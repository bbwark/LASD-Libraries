
#ifndef TESTX_HPP
#define TESTX_HPP

void testx() { std::cout << "# Other function" };

#endif
