
#ifndef TEST_HPP
#define TEST_HPP

void test();

const double pi = 3.14159;

#endif
