
namespace lasd
{

    /* ************************************************************************** */

    // ------------ NODE VEC -------------

    template <typename Data>
    BinaryTreeVec<Data>::NodeVec::NodeVec(const Data &data, unsigned long i, BinaryTreeVec<Data> *bt)
    {
        this->bt = bt;
        this->index = i;
        bt->elements[i] = data;
    }

    template <typename Data>
    BinaryTreeVec<Data>::NodeVec::NodeVec(Data &&data, unsigned long i, BinaryTreeVec<Data> *bt)
    {
        std::swap(this->bt, bt);
        std::swap(this->index, i);
        std::swap(bt->elements[i], data);
    }

    template <typename Data>
    bool BinaryTreeVec<Data>::NodeVec::HasLeftChild() const noexcept
    {
        if (index * 2 + 1 < bt->size)
        {
            return true;
        }
        return false;
    }

    template <typename Data>
    bool BinaryTreeVec<Data>::NodeVec::HasRightChild() const noexcept
    {
        if (index * 2 + 2 < bt->size)
        {
            return true;
        }
        return false;
    }

    template <typename Data>
    typename BinaryTreeVec<Data>::NodeVec &BinaryTreeVec<Data>::NodeVec::LeftChild()
    {
        if (HasLeftChild())
        {
            return (bt->nodes[index * 2 + 1]);
        }
        else
            throw std::out_of_range("Err: No Left Child Found");
    }

    template <typename Data>
    const typename BinaryTreeVec<Data>::NodeVec &BinaryTreeVec<Data>::NodeVec::LeftChild() const
    {
        if (HasLeftChild())
        {
            return (bt->nodes[index * 2 + 1]);
        }
        else
            throw std::out_of_range("Err: No Left Child Found");
    }

    template <typename Data>
    const typename BinaryTreeVec<Data>::NodeVec &BinaryTreeVec<Data>::NodeVec::RightChild() const
    {
        if (HasRightChild())
        {
            return (bt->nodes[index * 2 + 2]);
        }
        else
            throw std::out_of_range("Err: No Right Child Found");
    }

    template <typename Data>
    typename BinaryTreeVec<Data>::NodeVec &BinaryTreeVec<Data>::NodeVec::RightChild()
    {
        if (HasRightChild())
        {
            return (bt->nodes[index * 2 + 2]);
        }
        else
            throw std::out_of_range("Err: No Right Child Found");
    }

    // ----------- BINARY TREE VEC --------------

    template <typename Data>
    BinaryTreeVec<Data>::BinaryTreeVec(const TraversableContainer<Data> &cont)
    {
        this->Resize(cont.Size());
        nodes = new NodeVec[cont.Size()];
        int i = 0;

        cont.Traverse(
            [this, &i](const Data &dat)
            {
                this->nodes[i].index = i;
                elements[i] = dat;
                this->nodes[i].bt = this;
                i++;
            });
    }

    template <typename Data>
    BinaryTreeVec<Data>::BinaryTreeVec(MappableContainer<Data> &&cont) noexcept
    {
        this->Resize(cont.Size());
        nodes = new NodeVec[cont.Size()];
        int i = 0;
        cont.Map(
            [this, &i](Data &dat)
            {
                this->nodes[i].index = i;
                elements[i] = std::move(dat);
                this->nodes[i].bt = this;
                i++;
            });
    }

    template <typename Data>
    BinaryTreeVec<Data>::BinaryTreeVec(const BinaryTreeVec<Data> &btv)
    {
        this->Resize(btv.Size());
        nodes = new NodeVec[btv.Size()];
        std::copy(btv.elements, btv.elements + size, elements);
        std::copy(btv.nodes, btv.nodes + size, nodes);

        for (unsigned long i = 0; i < btv.Size(); i++)
        {
            nodes[i].bt = this;
        }
    }

    template <typename Data>
    BinaryTreeVec<Data>::BinaryTreeVec(BinaryTreeVec<Data> &&btv) noexcept
    {
        std::swap(this->size, btv.size);
        std::swap(elements, btv.elements);
        std::swap(nodes, btv.nodes);

        for (unsigned long i = 0; i < size; i++)
        {
            nodes[i].bt = this;
        }
    }

    template <typename Data>
    BinaryTreeVec<Data> &BinaryTreeVec<Data>::operator=(const BinaryTreeVec &btv)
    {
        this->Clear();
        this->Resize(btv.Size());
        nodes = new NodeVec[btv.Size()];
        std::copy(btv.elements, btv.elements + size, elements);
        std::copy(btv.nodes, btv.nodes + size, nodes);
        for (unsigned long i = 0; i < btv.Size(); i++)
        {
            nodes[i].bt = this;
        }
        return *this;
    }

    template <typename Data>
    BinaryTreeVec<Data> &BinaryTreeVec<Data>::operator=(BinaryTreeVec &&btv) noexcept
    {
        std::swap(this->size, btv.size);
        std::swap(elements, btv.elements);
        std::swap(nodes, btv.nodes);
        for (unsigned long i = 0; i < size; i++)
        {
            nodes[i].bt = this;
        }
        for (unsigned long i = 0; i < btv.size; i++)
        {
            btv.nodes[i].bt = &btv;
        }
        return *this;
    }

    template <typename Data>
    const typename BinaryTreeVec<Data>::NodeVec &BinaryTreeVec<Data>::Root() const
    {
        if (!this->Empty())
        {
            return nodes[0];
        }
        else
        {
            throw std::length_error("Err: Tree is Empty");
        }
    }

    template <typename Data>
    typename BinaryTreeVec<Data>::NodeVec &BinaryTreeVec<Data>::Root()
    {
        if (!this->Empty())
        {
            return nodes[0];
        }
        else
        {
            throw std::length_error("Err: Tree is Empty");
        }
    }
    /* ************************************************************************** */

}