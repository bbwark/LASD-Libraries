
#include "zlasdtest/test.hpp"

#include "zmytest/test.hpp"

/* ************************************************************************** */

#include <iostream>

/* ************************************************************************** */

int main()
{
  std::cout << "Lasd Libraries 2024" << std::endl;
  lasdtest();
  std::cout << "My Tests" << std::endl;
  mytest();
  return 0;
}
