
#ifndef EX2ATEST_HPP
#define EX2ATEST_HPP

/* ************************************************************************** */

void testSimpleExercise2A(unsigned int &, unsigned int &);

void testFullExercise2A(unsigned int &, unsigned int &);

/* ************************************************************************** */

#endif
